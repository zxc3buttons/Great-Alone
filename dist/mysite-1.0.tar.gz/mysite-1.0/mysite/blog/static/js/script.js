window.onload = function(){
    let x = document.querySelector("#myTopnav");
    document.querySelector("#menu").onclick = function(){
         x.classList.toggle('responsive');
    }
}
